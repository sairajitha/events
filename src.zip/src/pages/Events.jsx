import React from "react";
import {
  FaCalendarAlt,
  FaCheckCircle,
  FaClock,
  FaRedo,
  FaTimesCircle,
  FaSearch,
} from "react-icons/fa";

import EventCard from "../components/EventCard";
import StatCard from "../components/StatCard";
import { Link } from "react-router-dom";

const events = [
  {
    id: 1,
    date: "15",
    month: "MAR",
    title: "State of the Union Address Preparation",
    time: "10:00 AM - 11:30 AM",
    location: "Presidential Conference Room",
    status: "Confirmed",
    description:
      "Final review and preparation for the upcoming State of the Union address with speechwriters and policy advisors.",
  },
  {
    id: 2,
    date: "18",
    month: "MAR",
    title: "National Security Briefing",
    time: "2:00 PM - 3:30 PM",
    location: "Situation Room",
    status: "Pending Response",
    description:
      "Classified briefing on current international security threats and strategic response options.",
  },
];

export default function Events() {
  return (
    <div className="bg-gray-100 min-h-screen">

      {/* Top Section */}
      <div className="bg-purple-100 p-6 ">

        {/* Header */}
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-bold">Event Management</h1>

          <Link to="/event/create" className="bg-purple-600 text-white px-4 py-2 rounded-lg font-semibold shadow">
            + Post New Event
          </Link>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-5 gap-6">
          <StatCard title="Total Events" number="24" icon={<FaCalendarAlt />} />
          <StatCard title="Confirmed" number="16" icon={<FaCheckCircle />} />
          <StatCard title="Pending" number="5" icon={<FaClock />} />
          <StatCard title="Reschedule" number="2" icon={<FaRedo />} />
          <StatCard title="Declined" number="1" icon={<FaTimesCircle />} />
        </div>

      </div>

      {/* Search + Filters */}
      <div className="p-6">

        <div className="flex items-center justify-between gap-4 mb-6">

          {/* Search */}
          <div className="flex items-center bg-white border border-gray-200 rounded-lg px-3 py-2 flex-1 shadow-sm">
            <FaSearch className="text-gray-400 mr-2" />

            <input
              type="text"
              placeholder="Search events..."
              className="outline-none w-full"
            />
          </div>

          {/* Filters */}
          <div className="flex gap-2">

            <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg">
              All Events
            </button>

            <button className="bg-white px-4 py-2 border border-gray-300 rounded-lg">
              Confirmed
            </button>

            <button className="bg-white px-4 py-2 border border-gray-300 rounded-lg">
              Pending
            </button>

            <button className="bg-white px-4 py-2 border border-gray-300 rounded-lg">
              Needs Action
            </button>

            <button className="bg-white px-4 py-2 border border-gray-300 rounded-lg">
              Self Posted
            </button>

          </div>

        </div>

        {/* Event List */}
        <div className="space-y-4">
          {events.map((event) => (
            <EventCard key={event.id} event={event} />
          ))}
        </div>

      </div>

    </div>
  );
}