import { BrowserRouter, Routes, Route } from "react-router-dom";

import Layout from "./components/Layout";
import Home from "./pages/Home";
import EventDashboard from "./pages/EventDashboard";
import CreateEvent from "./pages/CreateEvent";
import Calendar from "./pages/Calendar";
import Schedule from "./pages/Schedule";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>

          <Route index element={<Home />} />
          <Route path="/events" element={<EventDashboard />} />
          <Route path="/event/create" element={<CreateEvent />} />
          <Route path="/calendar" element={<Calendar />} />
          <Route path="/schedule" element={<Schedule />} />

        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;