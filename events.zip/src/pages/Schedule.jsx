import { useState } from "react";

export default function ScheduleTabs() {

  const [activeTab, setActiveTab] = useState("today");

  const data = {
    today: [
      {
        time: "9:00 AM",
        title: "Cabinet Meeting",
        location: "Conference Room A · 1 hr",
        status: "Going"
      },
      {
        time: "2:00 PM",
        title: "Press Briefing",
        location: "East Wing · 45 min",
        status: "Pending"
      }
    ],

    tomorrow: [
      {
        time: "10:30 AM",
        title: "Strategy Meeting",
        location: "Board Room · 2 hr",
        status: "Going"
      }
    ],

    week: [
      {
        time: "1:00 PM",
        title: "Foreign Affairs Briefing",
        location: "Situation Room · 1 hr",
        status: "Pending"
      },
      {
        time: "4:00 PM",
        title: "Policy Review",
        location: "Oval Office · 30 min",
        status: "Going"
      }
    ],

    month: [
      {
        time: "3:00 PM",
        title: "Community Outreach",
        location: "Community Center · 2 hr",
        status: "Pending"
      }
    ]
  };

  const tabs = [
    { key: "today", label: "Today" },
    { key: "tomorrow", label: "Tomorrow" },
    { key: "week", label: "Next 7 Days" },
    { key: "month", label: "Month" }
  ];

  return (
    <div className="min-h-screen bg-gray-100 flex justify-center p-4">

      <div className="w-full max-w-md bg-white rounded-2xl shadow">

        {/* Header */}
        <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white p-5 rounded-t-2xl">

          <h2 className="text-lg font-semibold">
            My Schedule
          </h2>

          <p className="text-sm opacity-90">
            Wednesday, 18 June 2025
          </p>

          {/* Tabs */}
          <div className="flex mt-4 bg-indigo-700/40 rounded-full p-1">

            {tabs.map((tab) => (

              <button
                key={tab.key}
                onClick={() => setActiveTab(tab.key)}
                className={`flex-1 text-sm py-1 rounded-full transition
                ${
                  activeTab === tab.key
                    ? "bg-indigo-500 text-white"
                    : "text-white/80"
                }`}
              >
                {tab.label}
              </button>

            ))}

          </div>

        </div>

        {/* Events */}
        <div className="p-4 space-y-4">

          {data[activeTab].map((event, index) => (

            <div
              key={index}
              className="flex items-center justify-between bg-gray-50 rounded-xl p-4"
            >

              <div>

                <h3 className="font-semibold">
                  {event.title}
                </h3>

                <p className="text-sm text-gray-500">
                  {event.location}
                </p>

                <p className="text-sm mt-1">
                  {event.time}
                </p>

              </div>

              <span
                className={`text-xs px-3 py-1 rounded-full
                ${
                  event.status === "Going"
                    ? "bg-green-100 text-green-700"
                    : "bg-gray-200 text-gray-600"
                }`}
              >
                {event.status}
              </span>

            </div>

          ))}

        </div>

      </div>

    </div>
  );
}