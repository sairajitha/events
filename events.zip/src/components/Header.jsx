import { Bell } from "lucide-react";

export default function Header() {
  return (
    <header className="flex items-center justify-between bg-white px-6 py-3 border-b">

      {/* Left Side */}
      <div className="flex items-center gap-3">
        <div className="bg-purple-600 w-10 h-10 rounded-lg flex items-center justify-center">
          <span className="text-white text-xl">📅</span>
        </div>

        <h1 className="text-lg font-semibold text-gray-800">
          Assistant Dashboard
        </h1>
      </div>

      {/* Right Side */}
      <div className="flex items-center gap-6">

        {/* Notification */}
        <div className="relative">
          <Bell className="text-gray-500 w-5 h-5" />

          <span className="absolute -top-1 -right-1 w-2 h-2 bg-purple-500 rounded-full"></span>
        </div>

        {/* User */}
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-medium text-gray-800">
              Sarah Johnson
            </p>
            <p className="text-xs text-gray-500">
              Executive Assistant
            </p>
          </div>

          <div className="bg-purple-100 text-purple-600 w-9 h-9 rounded-lg flex items-center justify-center font-semibold">
            SJ
          </div>
        </div>

      </div>

    </header>
  );
}