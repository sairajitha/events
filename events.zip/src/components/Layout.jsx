import { Outlet } from "react-router-dom";
import Navbar from "./Navbar";
import Header from "./Header";
import Footer from "./Footer";

function Layout() {
  return (
    <div>
      <Header />

      <div className="">
        <Outlet />
      </div>
    <Footer />
    </div>
  );
}

export default Layout;